function ExecuteScript(strId)
{
  switch (strId)
  {
      case "63W6dPHLSie":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

