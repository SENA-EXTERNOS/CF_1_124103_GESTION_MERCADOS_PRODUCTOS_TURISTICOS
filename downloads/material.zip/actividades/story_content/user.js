function ExecuteScript(strId)
{
  switch (strId)
  {
      case "64h00GdFZoi":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

